import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Header from './Component/Header/Header';
import Footer from './Component/Footer/Footer';
import SearchSort from './Component/SearchSort/SearchSort';
import RepoList from './Component/RepoList/RepoList';
import RepoCard from './Component/RepoCard/RepoCard';

const App = () => {
  const [repos, setRepos] = useState([]);
  const [theme, setTheme] = useState('light');

  useEffect(() => {
    fetch('https://api.github.com/repositories')
      .then(response => response.json())
      .then(data => setRepos(data))
      .catch(error => console.error('Error fetching data:', error));
  }, []);
  

  const handleReposUpdate = (updatedRepos) => {
    setRepos(updatedRepos);
  };

  const handleThemeChange = (theme) => {
    setTheme(theme);
    document.body.className = theme === 'dark' ? 'dark-mode' : '';
  };

  return (
    
      <div className={`container ${theme}`}>
        <Header />
        <SearchSort 
          onReposUpdate={handleReposUpdate} 
          onThemeChange={handleThemeChange} 
        />
        
          {/* <RepoList repos={repos} /> */}
          <RepoCard repos={repos} />
        
        <Footer />
      </div>
    
  );
};

export default App;
