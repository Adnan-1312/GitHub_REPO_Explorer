// Component/RepoCard/RepoCard.js
import React from 'react';
import './repoCard.css'
// import { useParams } from 'react-router-dom';

const RepoCard = ({ repos }) => {
  // const { id } = useParams();
  // const repo = repos.find(repo => repo.id.toString() === id);
  console.log("hfsddfshdfshj",repos);

  // if (!repo) {
  //   return <div>Repository not found</div>;
  // }

  return (
    <div id='repoList'>
      {repos.map((repo)=>{
        return(
          <div className="repo-card">
            <h2 className="repo-name">{repo.name}</h2>
            <p className="repo-description">{repo.description}</p>
            <div className="repo-stats">
              <span className="stars">⭐ {repo.stargazers_count}</span>
              <span className="forks">🍴 {repo.forks_count}</span>
              <span className="language">{repo.language}</span>
            </div>
          </div>
        )
      })}
    </div>
  );
};

export default RepoCard;
