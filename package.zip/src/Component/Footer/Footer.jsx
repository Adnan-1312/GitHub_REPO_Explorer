import React from 'react';

const Footer = () => {
  return (
    <footer>
      <p>Project made by Adnan Pathan, Anish Pawar, Ashwini Kotagonde</p>
    </footer>
  );
};

export default Footer;
