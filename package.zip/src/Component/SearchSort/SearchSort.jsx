// Component/SearchSort/SearchSort.js
import React, { useState } from 'react';
import './SearchSort.css'

const SearchSort = ({ onReposUpdate, onThemeChange }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [sortType, setSortType] = useState('stars');
  const [theme, setTheme] = useState('light');

  const handleSearch = () => {
    fetch('https://api.github.com/repositories')
      .then(response => response.json())
      .then(data => {
        const filteredRepos = data.filter(repo =>
          repo.name.toLowerCase().includes(searchTerm.toLowerCase())
        );
        onReposUpdate(filteredRepos);
      })
      .catch(error => console.error('Error fetching data:', error));
  };

  const handleSortChange = (event) => {
    setSortType(event.target.value);
    fetch('https://api.github.com/repositories')
      .then(response => response.json())
      .then(data => {
        const sortedRepos = data.sort((a, b) =>
          event.target.value === 'stars' ? b.stargazers_count - a.stargazers_count : b.forks_count - a.forks_count
        );
        onReposUpdate(sortedRepos);
      })
      .catch(error => console.error('Error fetching data:', error));
  };

  const handleThemeChange = (event) => {
    setTheme(event.target.value);
    onThemeChange(event.target.value);
  };

  return (
    <div className="search-sort-theme">
      <div className="search_Box">
      <input
        className="search_Bar"
        type="text"
        placeholder="Search repositories..."
        value={searchTerm}
        onChange={(e) => setSearchTerm(e.target.value)}
      />
      <button className="search_Btn" onClick={handleSearch}>Search</button>
      </div>
      <div className='Search-button1'>
      <select value={sortType} onChange={handleSortChange} className='sort-btn'>
        <option value="stars">Sort by Stars</option>
        <option value="forks">Sort by Forks</option>
      </select>
      </div>
      <div className='Search-button2'>
      <select value={theme} onChange={handleThemeChange} className='them-btn'>
        <option value="light">Light Theme</option>
        <option value="dark">Dark Theme</option>
      </select>
      </div>
    </div>
  );
};

export default SearchSort;
